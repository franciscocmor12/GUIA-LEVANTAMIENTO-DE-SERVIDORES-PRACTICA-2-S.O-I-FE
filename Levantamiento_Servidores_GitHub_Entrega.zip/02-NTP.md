> **Práctica 3 — Sistemas Operativos I | CentOS Stream + VirtualBox (adaptador puente)**
> **Integrantes:** Francisco Morillo y Esteban Nievecela

# 02 — Servidor NTP: sincronización horaria con Chrony

**Propósito:** ofrecer al equipo Windows una referencia horaria desde CentOS Stream. **El archivo NTP.md original estaba vacío**, por lo que esta sección es una propuesta de implementación y no evidencia de una prueba realizada.

## 1. Diagnóstico inicial

Se comprueba el sistema operativo, la dirección IP, los servicios disponibles y el estado del cortafuegos antes de realizar modificaciones.

```bash
cat /etc/os-release
ip -br a
sudo firewall-cmd --state
getenforce
```

**Evidencia pendiente:** captura del diagnóstico en la máquina virtual.

## 2. Arquitectura y requisitos

El equipo Windows funciona como cliente y anfitrión de VirtualBox. La máquina virtual CentOS Stream utiliza un adaptador de red en **modo puente** para que ambos equipos se comuniquen dentro de la misma red. Las conexiones se realizan usando la IP de CentOS, obtenida con `ip -br a`.

**Requisitos:** CentOS Stream, VirtualBox en modo puente, conectividad entre equipos y permisos de administración.

### Diagrama del servicio

```text
Windows (cliente de hora) ── NTP UDP 123 ──> CentOS / chronyd
                                         │
                                  Fuentes horarias externas
```

## 3. Despliegue y configuración

```bash
sudo dnf install -y chrony
sudo systemctl enable --now chronyd
sudo cp /etc/chrony.conf /etc/chrony.conf.bak
sudo nano /etc/chrony.conf
```

En `/etc/chrony.conf`, conservar las fuentes horarias existentes y agregar una regla `allow` para **la subred real de laboratorio**, por ejemplo (solo si corresponde a su red):

```text
allow RED_DEL_LABORATORIO/PREFIJO
```

Reemplazar el marcador por la red autorizada; no copiarlo literalmente. Si se necesita servir hora durante una desconexión de Internet, evaluar `local stratum 10` como opción de laboratorio y documentar sus limitaciones (no garantiza hora exacta).

```bash
sudo systemctl restart chronyd
chronyc tracking
chronyc sources -v
```

## 4. Aseguramiento de seguridad: SELinux y Firewalld

```bash
sudo firewall-cmd --permanent --add-service=ntp
sudo firewall-cmd --reload
sudo firewall-cmd --list-services
getenforce
sudo ss -lunp | grep ':123'
```

Restringir el acceso NTP con `allow` a la red autorizada y comprobar que SELinux permanece en modo `Enforcing` cuando corresponda.

> **Nota de seguridad:** mantener SELinux activo y abrir únicamente los puertos necesarios. Si una prueba falla, diagnosticar primero; no desactivar permanentemente SELinux ni Firewalld.

## 5. Pruebas de aceptación

| Prueba | Comando / acción | Resultado esperado |
|---|---|---|
| Servicio | `systemctl is-active chronyd` | `active` |
| Fuentes | `chronyc sources -v` | Fuentes disponibles y estado verificable |
| Estado de reloj | `chronyc tracking` | Datos de referencia y desviación |
| Cliente Windows | `w32tm /stripchart /computer:IP_CENTOS /samples:5 /dataonly` | Respuestas NTP con desfase medible |

En Windows, ejecutar CMD con permisos apropiados y, si se requiere sincronizar el reloj del sistema, configurar el servidor NTP con las herramientas de Windows y comprobar el resultado con `w32tm /query /status`. **Cambiar la hora del anfitrión puede afectar otras aplicaciones; realizarlo únicamente en un entorno de práctica autorizado.**

**Evidencias pendientes:** `chronyc tracking`, consulta desde Windows y hora antes/después.

## 6. Troubleshooting y contingencia

| Problema | Diagnóstico | Solución |
|---|---|---|
| Windows no recibe respuesta | `ss -lunp`, firewall y `allow` | Revisar UDP 123, IP y subred autorizada |
| CentOS no está sincronizado | `chronyc sources -v` | Verificar conectividad y fuentes NTP |
| Desfase persistente | `chronyc tracking` | Comprobar zona horaria y origen horario; no confundir zona con sincronización |

**Recuperación:** restaurar `/etc/chrony.conf.bak`, reiniciar `chronyd` y verificar `chronyc tracking`.
