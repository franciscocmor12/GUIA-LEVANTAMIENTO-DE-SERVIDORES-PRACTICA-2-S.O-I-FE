# Levantamiento de Servidores — Práctica 3

**Integrantes:** Francisco Morillo y Esteban Nievecela  
**Asignatura:** Sistemas Operativos I (Linux)  
**Entorno:** CentOS Stream en VirtualBox, Windows como anfitrión, red en modo puente.

## Introducción

Este repositorio reúne los procedimientos de despliegue, diagnóstico, aseguramiento y validación de servicios de red sobre CentOS Stream. Se documentan SSH para administración remota, Chrony/NTP para sincronización horaria, vsftpd para transferencia de archivos y Apache HTTPD para publicación web. Las pruebas se presentan como **criterios de aceptación**; donde no existe evidencia original se indica expresamente.

## 5.1. Diagrama de arquitectura y topología

```mermaid
flowchart LR
    W[Windows: anfitrión y cliente] --> B[Red local / adaptador puente]
    B --> C[CentOS Stream en VirtualBox]
    C --> S[SSH TCP 2237: administración]
    C --> N[NTP UDP 123: sincronización]
    C --> F[FTP TCP 21 + pasivos: archivos]
    C --> H[HTTP TCP 80: página web]
    C --> P[Firewalld y SELinux]
```

Windows se comunica con la IP asignada a CentOS en la red local. MobaXterm accede por SSH y FTP, el navegador accede por HTTP y el cliente horario de Windows consulta NTP. **El diagrama representa la arquitectura propuesta; no acredita por sí solo que los servicios estén activos.**

## Servicios documentados

| Servicio | Archivo | Función |
|---|---|---|
| SSH | [01-SSH.md](01-SSH.md) | Administración remota |
| NTP | [02-NTP.md](02-NTP.md) | Sincronización horaria |
| FTP | [03-FTP.md](03-FTP.md) | Transferencia de archivos |
| HTTP | [04-HTTP.md](04-HTTP.md) | Página web personalizada |

## 5.2. Matriz de puertos y seguridad

| Servicio | Protocolo / puerto | Firewalld | SELinux / control |
|---|---|---|---|
| SSH | TCP 2237 | `--add-port=2237/tcp` | Tipo `ssh_port_t` para puerto personalizado |
| NTP | UDP 123 | `--add-service=ntp` | `chronyd` y clientes permitidos por `allow` |
| FTP | TCP 21 y TCP 30000–30009 | `--add-service=ftp` y rango pasivo | Permisos y contextos del directorio de transferencia |
| HTTP | TCP 80 | `--add-service=http` | Contexto de contenido web `httpd_sys_content_t` |

**Nota:** TCP 443 se utiliza únicamente si se configura HTTPS; FTP activo puede requerir manejo adicional de conexiones de datos. En esta documentación se propone FTP pasivo.

## 5.3. Pruebas de aceptación y QA

Las tablas de cada servicio muestran **comandos de verificación y resultados esperados**. Se deben adjuntar capturas obtenidas en CentOS y Windows, registrar el resultado real y distinguir pruebas aprobadas, fallidas o pendientes.

## 5.4. Plan de contingencia

1. **Fallo de acceso remoto:** verificar servicio SSH, puerto 2237, reglas de Firewalld y etiqueta SELinux; recuperar desde consola de VirtualBox si es necesario.
2. **FTP no permite transferencias:** revisar cuenta sin shell, autenticación PAM, directorio de carga, rango pasivo y registros SELinux.
3. **Página web o NTP no responden:** comprobar estado del servicio, conectividad puente, puertos y configuración; restaurar respaldos si un cambio impide el servicio.

## 5.5. Organización de la wiki

Cada archivo contiene diagnóstico, arquitectura, despliegue, aseguramiento SELinux/Firewalld, pruebas de aceptación y troubleshooting. Los archivos Markdown se pueden usar directamente en el repositorio o copiar a páginas de GitHub Wiki.

## Evidencias y estado de la documentación

- **SSH:** el repositorio original incluye una captura de sesión remota.
- **FTP:** el repositorio original incluye una captura de prueba FTP.
- **HTTP:** el repositorio original incluye capturas de edición y resultado de la página.
- **NTP:** el archivo original estaba vacío; faltan configuración y evidencias reales.

Los enlaces a imágenes del proyecto original se conservan dentro de los apartados correspondientes. Se deben comprobar después de subir los archivos a GitHub.

## Conclusión

La práctica integra cuatro servicios de red con controles de acceso y verificaciones operativas. Su validación final depende de ejecutar las pruebas, guardar evidencias y documentar cualquier incidencia observada en el entorno de laboratorio.
