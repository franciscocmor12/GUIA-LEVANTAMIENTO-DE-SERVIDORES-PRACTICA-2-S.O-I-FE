> **Práctica 3 — Sistemas Operativos I | CentOS Stream + VirtualBox (adaptador puente)**
> **Integrantes:** Francisco Morillo y Esteban Nievecela

# 04 — Servidor HTTP: Apache y página personalizada

**Propósito:** publicar una página web con los nombres de los integrantes y una imagen accesible desde el navegador de Windows.

## 1. Diagnóstico inicial

Se comprueba el sistema operativo, la dirección IP, los servicios disponibles y el estado del cortafuegos antes de realizar modificaciones.

```bash
cat /etc/os-release
ip -br a
sudo firewall-cmd --state
getenforce
```

**Evidencia pendiente:** captura del diagnóstico en la máquina virtual.

## 2. Arquitectura y requisitos

El equipo Windows funciona como cliente y anfitrión de VirtualBox. La máquina virtual CentOS Stream utiliza un adaptador de red en **modo puente** para que ambos equipos se comuniquen dentro de la misma red. Las conexiones se realizan usando la IP de CentOS, obtenida con `ip -br a`.

**Requisitos:** CentOS Stream, VirtualBox en modo puente, conectividad entre equipos y permisos de administración.

### Diagrama del servicio

```text
Windows / navegador ── HTTP TCP 80 ──> CentOS / Apache httpd
                                         └── /var/www/html/index.html
                                             /var/www/html/images.jpg
```

## 3. Despliegue y configuración

```bash
sudo dnf install -y httpd
sudo systemctl enable --now httpd
httpd -v
sudo systemctl status httpd
sudo mkdir -p /var/www/html
```

El proyecto original editaba `/usr/share/httpd/noindex/index.html` pero copiaba la imagen a `/var/www/html/`, provocando una inconsistencia. Para una página propia, utilizar **`/var/www/html/index.html`**.

Si ya existe una página propia, respaldarla:

```bash
sudo test ! -f /var/www/html/index.html || sudo cp /var/www/html/index.html /var/www/html/index.html.bak
sudo nano /var/www/html/index.html
```

Ejemplo mínimo de contenido:

```html
<!doctype html>
<html lang="es">
<head><meta charset="utf-8"><title>Levantamiento de Servidores</title></head>
<body>
  <h1>Práctica 3 — Servidor HTTP en CentOS</h1>
  <p>Francisco Morillo y Esteban Nievecela</p>
  <img src="images.jpg" alt="Imagen institucional" width="180">
</body>
</html>
```

Copiar la imagen que ya posean a la carpeta web (sustituir la ruta de origen por la real):

```bash
sudo cp /RUTA/REAL/images.jpg /var/www/html/images.jpg
sudo chmod 644 /var/www/html/index.html /var/www/html/images.jpg
sudo restorecon -Rv /var/www/html
```

## 4. Aseguramiento de seguridad: SELinux y Firewalld

```bash
sudo firewall-cmd --permanent --add-service=http
sudo firewall-cmd --reload
sudo firewall-cmd --list-services
ls -Z /var/www/html/index.html /var/www/html/images.jpg
getenforce
```

Para contenido estático, los archivos deben tener contexto apropiado, habitualmente `httpd_sys_content_t`. El puerto 443 solo es necesario si se configura HTTPS; no se abre por defecto en esta práctica.

> **Nota de seguridad:** mantener SELinux activo y abrir únicamente los puertos necesarios. Si una prueba falla, diagnosticar primero; no desactivar permanentemente SELinux ni Firewalld.

## 5. Pruebas de aceptación

| Prueba | Comando / acción | Resultado esperado |
|---|---|---|
| Servicio | `systemctl is-active httpd` | `active` |
| Página local | `curl -I http://localhost/` | Respuesta HTTP, idealmente `200 OK` |
| Acceso Windows | Abrir `http://IP_CENTOS/` | Página personalizada visible |
| Imagen | Abrir `http://IP_CENTOS/images.jpg` | Imagen cargada |

**Capturas originales:**

![Edición del servidor web](https://github.com/user-attachments/assets/2b97b190-c209-4688-abee-023426ff9d65)

![Resultado web](https://github.com/user-attachments/assets/27c78b6c-0625-49ad-b11e-1b4755c7a635)

**Evidencias pendientes:** confirmar en la VM que la página y la imagen están servidas desde las rutas corregidas.

## 6. Troubleshooting y contingencia

| Problema | Diagnóstico | Solución |
|---|---|---|
| `403 Forbidden` | `ls -l`, `ls -Z`, registros de Apache | Ajustar permisos y restaurar contextos con `restorecon` |
| `404 Not Found` | Revisar ruta y nombre del archivo | Confirmar `/var/www/html/index.html` e `images.jpg` |
| Windows no abre la web | `curl -I localhost`, firewall y red | Comprobar servicio, TCP 80 y modo puente |

**Recuperación:** restaurar `index.html.bak` si existe y validar nuevamente con `curl`.
