> **Práctica 3 — Sistemas Operativos I | CentOS Stream + VirtualBox (adaptador puente)**
> **Integrantes:** Francisco Morillo y Esteban Nievecela

# 01 — Servidor SSH: acceso remoto seguro

**Propósito:** administrar CentOS desde Windows con MobaXterm usando el puerto personalizado **2237/TCP**, tal como se documentó en el proyecto original.

## 1. Diagnóstico inicial

Se comprueba el sistema operativo, la dirección IP, los servicios disponibles y el estado del cortafuegos antes de realizar modificaciones.

```bash
cat /etc/os-release
ip -br a
sudo firewall-cmd --state
getenforce
```

**Evidencia pendiente:** captura del diagnóstico en la máquina virtual.

## 2. Arquitectura y requisitos

El equipo Windows funciona como cliente y anfitrión de VirtualBox. La máquina virtual CentOS Stream utiliza un adaptador de red en **modo puente** para que ambos equipos se comuniquen dentro de la misma red. Las conexiones se realizan usando la IP de CentOS, obtenida con `ip -br a`.

**Requisitos:** CentOS Stream, VirtualBox en modo puente, conectividad entre equipos y permisos de administración.

### Diagrama del servicio

```text
Windows / MobaXterm ── SSH TCP 2237 ──> CentOS Stream / sshd
```

## 3. Despliegue y configuración

### Instalar y comprobar SSH

```bash
sudo dnf install -y openssh-server policycoreutils-python-utils
sudo systemctl enable --now sshd
sudo systemctl status sshd
```

`openssh-server` proporciona el servicio `sshd`; `systemctl` lo habilita y permite comprobar su estado.

### Configurar el puerto 2237

Hacer una copia de seguridad y editar la configuración:

```bash
sudo cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak
sudo nano /etc/ssh/sshd_config
```

Configurar una sola directiva activa:

```text
Port 2237
```

Guardar con **Ctrl+O**, Enter, **Ctrl+X**. Antes de reiniciar, configurar SELinux y el firewall (sección 4). **Mantener abierta la sesión SSH actual** hasta confirmar una nueva conexión.

## 4. Aseguramiento de seguridad: SELinux y Firewalld

```bash
sudo semanage port -l | grep ssh_port_t
sudo semanage port -a -t ssh_port_t -p tcp 2237
sudo firewall-cmd --permanent --add-port=2237/tcp
sudo firewall-cmd --reload
sudo sshd -t
sudo systemctl restart sshd
sudo ss -lntp | grep 2237
```

Si `semanage` indica que el puerto ya está definido para otro tipo, revisar el conflicto antes de cambiarlo. **No retirar el puerto 22 hasta verificar que el acceso por 2237 funciona.**

> **Nota de seguridad:** mantener SELinux activo y abrir únicamente los puertos necesarios. Si una prueba falla, diagnosticar primero; no desactivar permanentemente SELinux ni Firewalld.

## 5. Pruebas de aceptación

| Prueba | Comando o acción | Resultado esperado |
|---|---|---|
| Servicio activo | `sudo systemctl is-active sshd` | `active` |
| Puerto escuchando | `sudo ss -lntp \| grep 2237` | `sshd` en TCP 2237 |
| Firewall | `sudo firewall-cmd --list-ports` | `2237/tcp` |
| Acceso remoto | `ssh -p 2237 USUARIO@IP_CENTOS` | Solicitud de autenticación y acceso permitido |

En **MobaXterm → Session → SSH**, escribir la IP de CentOS, el usuario autorizado y el puerto **2237**.

**Captura ya existente en el proyecto original:**

![Sesión SSH en MobaXterm](https://github.com/user-attachments/assets/c7447515-4ee3-41cf-93d6-1b194b0bf4c3)

**Evidencia adicional pendiente:** estado de `sshd`, puerto escuchando y configuración del firewall.

## 6. Troubleshooting y contingencia

| Incidencia | Diagnóstico | Solución |
|---|---|---|
| `Connection refused` | `sudo systemctl status sshd` y `sudo ss -lntp` | Revisar `Port 2237`, validar `sudo sshd -t` y reiniciar el servicio |
| Tiempo de espera | `sudo firewall-cmd --list-all` y `ip -br a` | Revisar adaptador puente, IP y regla TCP 2237 |
| SELinux impide iniciar | `sudo ausearch -m AVC -ts recent` | Verificar la etiqueta `ssh_port_t` con `semanage port -l` |

**Recuperación:** si el acceso remoto falla, entrar por la consola de VirtualBox, restaurar `/etc/ssh/sshd_config.bak`, comprobar con `sshd -t` y reiniciar `sshd`.
