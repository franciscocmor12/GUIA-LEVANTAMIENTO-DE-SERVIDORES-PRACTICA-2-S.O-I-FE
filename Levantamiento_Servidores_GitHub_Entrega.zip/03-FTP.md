> **Práctica 3 — Sistemas Operativos I | CentOS Stream + VirtualBox (adaptador puente)**
> **Integrantes:** Francisco Morillo y Esteban Nievecela

# 03 — Servidor FTP: transferencia restringida con vsftpd

**Propósito:** transferir archivos entre Windows y CentOS con una cuenta dedicada sin acceso interactivo a la terminal. **FTP convencional no cifra las credenciales**: usar únicamente una red de laboratorio controlada; en producción se prefiere SFTP o FTPS.

## 1. Diagnóstico inicial

Se comprueba el sistema operativo, la dirección IP, los servicios disponibles y el estado del cortafuegos antes de realizar modificaciones.

```bash
cat /etc/os-release
ip -br a
sudo firewall-cmd --state
getenforce
```

**Evidencia pendiente:** captura del diagnóstico en la máquina virtual.

## 2. Arquitectura y requisitos

El equipo Windows funciona como cliente y anfitrión de VirtualBox. La máquina virtual CentOS Stream utiliza un adaptador de red en **modo puente** para que ambos equipos se comuniquen dentro de la misma red. Las conexiones se realizan usando la IP de CentOS, obtenida con `ip -br a`.

**Requisitos:** CentOS Stream, VirtualBox en modo puente, conectividad entre equipos y permisos de administración.

### Diagrama del servicio

```text
Windows / cliente FTP ── TCP 21 + puertos pasivos ──> CentOS / vsftpd
                                                   └── /srv/ftp/ftp_estudiante/upload
```

## 3. Despliegue y configuración

```bash
sudo dnf install -y vsftpd
sudo systemctl enable --now vsftpd
sudo cp /etc/vsftpd/vsftpd.conf /etc/vsftpd/vsftpd.conf.bak
sudo useradd -m -s /sbin/nologin ftp_estudiante
sudo passwd ftp_estudiante
sudo mkdir -p /home/ftp_estudiante/upload
sudo chown root:root /home/ftp_estudiante
sudo chmod 755 /home/ftp_estudiante
sudo chown ftp_estudiante:ftp_estudiante /home/ftp_estudiante/upload
sudo nano /etc/vsftpd/vsftpd.conf
```

La guía exige un usuario sin shell. En el proyecto original se alternaban `usuario_ftp` y `epnbrow_ftp`; aquí se unifica como `ftp_estudiante`.

Verificar que el archivo incluya **una sola versión activa** de estas directivas:

```ini
anonymous_enable=NO
local_enable=YES
write_enable=YES
chroot_local_user=YES
allow_writeable_chroot=NO
pasv_enable=YES
pasv_min_port=30000
pasv_max_port=30009
```

La carpeta principal del usuario no es escribible y `upload` sí lo es. Para permitir que una cuenta con `/sbin/nologin` autentique mediante PAM, revisar `/etc/pam.d/vsftpd` y `/etc/shells` según la política del sistema: agregar `/sbin/nologin` a `/etc/shells` **solo en el laboratorio y con autorización**, porque afecta a la validación de shells para otros servicios. No modificar PAM sin verificar primero el error de autenticación.

```bash
sudo systemctl restart vsftpd
sudo systemctl status vsftpd
```

## 4. Aseguramiento de seguridad: SELinux y Firewalld

```bash
sudo firewall-cmd --permanent --add-service=ftp
sudo firewall-cmd --permanent --add-port=30000-30009/tcp
sudo firewall-cmd --reload
sudo firewall-cmd --list-all
getenforce
ls -Zd /home/ftp_estudiante /home/ftp_estudiante/upload
```

Los permisos y contextos SELinux deben validarse sobre el directorio real. Si SELinux bloquea escritura, revisar los eventos AVC y aplicar **una política o etiquetado específico** adecuado al sistema; no utilizar `setenforce 0` como solución definitiva.

> **Nota de seguridad:** mantener SELinux activo y abrir únicamente los puertos necesarios. Si una prueba falla, diagnosticar primero; no desactivar permanentemente SELinux ni Firewalld.

## 5. Pruebas de aceptación

| Prueba | Acción | Resultado esperado |
|---|---|---|
| Servicio | `systemctl is-active vsftpd` | `active` |
| Puerto | `ss -lntp \| grep ':21'` | Puerto de control disponible |
| Transferencia | Conectar con cliente FTP, subir y descargar archivo de prueba | Transferencia completada |
| Shell bloqueada | `ssh ftp_estudiante@IP_CENTOS` | Acceso interactivo denegado |

**Captura del proyecto original:**

![Prueba FTP](https://github.com/user-attachments/assets/13366408-e56c-44ab-82f8-dc454b5f9cc5)

**Evidencias pendientes:** conexión FTP con el usuario definitivo, subida/descarga y denegación de shell.

## 6. Troubleshooting y contingencia

| Problema | Diagnóstico | Solución |
|---|---|---|
| `530 Login incorrect` | Usuario, contraseña, PAM y shells válidos | Verificar `ftp_estudiante` y reglas PAM aplicables |
| Lista de archivos falla | Firewall y puertos pasivos | Abrir y configurar el mismo rango TCP 30000–30009 |
| `550 Permission denied` | `ls -ld`, `ls -Z`, registros AVC | Corregir propiedad de `upload` y contexto SELinux pertinente |

**Recuperación:** restaurar `vsftpd.conf.bak`, reiniciar `vsftpd` y comprobar acceso local antes de repetir la prueba remota.
