# Evidencias

Guardar aquí las capturas reales de CentOS, Windows y MobaXterm. Sustituir los marcadores de evidencia pendiente en cada servicio. No publicar contraseñas ni información privada.
